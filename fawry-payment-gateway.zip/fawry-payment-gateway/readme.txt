=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://paypal.me/NadyShalaby
Tags: fawry, payment, woocommerce
Requires at least: 5.x
Tested up to: 5.x
Stable tag: 5.x
Requires PHP: 7.1.13
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Fawry payment through credit cart & Fawry Machines.

== Description ==

Fawry payment gateway is a powerful payment processor that helps you pay through credit cart & Fawry Machines.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/fawry-payment-gateway` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Woocommerce->Settings->Payments screen to configure the plugin


== Frequently Asked Questions ==

= Is there testing mode available? =

Yes it have.

= What about languages & localiztions? =

This plugin supports both languages (e.g. English, Arabic).

== Screenshots ==

1. /assets/screenshot-1.png
2. /assets/screenshot-2.png
3. /assets/screenshot-3.png
4. /assets/screenshot-4.png

== Changelog ==

= 1.0 =
* A fresh stable release for Fawry Pay.
